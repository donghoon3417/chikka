function showMyPage(){

  if(!currentUser){
    alert("로그인 필요");
    return;
  }

  google.script.run
    .withSuccessHandler(function(data){

      if(!data){
        alert("사용자 정보 없음");
        return;
      }

      document.getElementById("m_id").value = data.id || "";
      document.getElementById("m_score4").value = data.score4 || 0;
      document.getElementById("m_score3").value = data.score3 || 0;
      document.getElementById("m_hr4").value = data.highrun4 || 0;
      document.getElementById("m_hr3").value = data.highrun3 || 0;
      document.getElementById("m_place").value = data.place || "";

      document.getElementById("mypage").style.display = "block";

    })
    .withFailureHandler(err=>{
      alert("오류: " + err.message);
    })
    .getMyInfo(currentUser.id);
}
function updateMyInfo(){

  const data = {
    id: document.getElementById("m_id").value,
    score4: Number(document.getElementById("m_score4").value) || 0,
    score3: Number(document.getElementById("m_score3").value) || 0,
    highrun4: Number(document.getElementById("m_hr4").value) || 0,
    highrun3: Number(document.getElementById("m_hr3").value) || 0,
    place: document.getElementById("m_place").value || ""
  };

  console.log("보내는 데이터:", data); // 🔥 디버깅

  google.script.run
    .withSuccessHandler(function(res){
      alert("수정 완료");
      loadRanking(4);
      closeMyPage();
    })
    .withFailureHandler(function(err){
      alert("저장 실패: " + err.message);
    })
    .updateMyInfo(data);
}

function closeMyPage(){
  document.getElementById("mypage").style.display = "none";
}