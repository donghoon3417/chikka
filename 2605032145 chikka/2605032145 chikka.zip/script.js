  let currentUser = null;


function loadRanking(type){

  google.script.run
    .withSuccessHandler(renderTable)
    .getRanking(String(type));

}

// 테이블 출력
function renderTable(data){

  const tbody = document.querySelector("#rankingTable tbody");
  tbody.innerHTML = "";

data.forEach((u,i)=>{

  const tr = document.createElement("tr");
let deleteBtn = "";

if(currentUser && currentUser.role === "admin"){
  deleteBtn = `<td><button onclick="removeUser('${u.id}')">삭제</button></td>`;
}else{
  deleteBtn = `<td></td>`;
}

tr.innerHTML = `
  <td>${u.rank}</td>
  <td>${u.id}</td>
  <td>${u.tier}</td>
  <td>${u.score || 0}</td>
  <td>${u.highrun || 0}</td>
  <td>${u.place || ""}</td>
`;

  tbody.appendChild(tr);
});
}
function signup(){

  google.script.run
    .withSuccessHandler(res=>{

      if(res.error){
        alert(res.error);
        return;
      }

      alert("회원가입 완료");
      // ⭐ 추가
showLogin();

      // ⭐ 입력값 초기화 (선택)
      s_id.value="";
      s_pw.value="";
      s_score4.value="";
      s_score3.value="";
      s_hr4.value="";
      s_hr3.value="";
      s_place.value=""; // ⭐ 이것도 추가

      // ⭐ 랭킹 즉시 갱신
      loadRanking(4);

    })
 .signup({
  id: s_id.value,
  password: s_pw.value,
  score4: Number(s_score4.value),
  score3: Number(s_score3.value),
  highrun4: Number(s_hr4.value),
  highrun3: Number(s_hr3.value),
  place: s_place.value   // ⭐ 이거 추가
});
}

function loadUsers(){

  google.script.run
    .withSuccessHandler(data=>{

      const tbody = document.querySelector("#userTable tbody");
      tbody.innerHTML = "";

      data.forEach(u=>{
        const tr = document.createElement("tr");

        tr.innerHTML = `
          <td>${u.no}</td>
          <td>${u.id}</td>
          <td>${u.score4}</td>
          <td>${u.score3}</td>
          <td>${u.highrun4}</td>
          <td>${u.highrun3}</td>
          <td><button onclick="removeUser('${u.id}')">삭제</button></td>
        `;

        tbody.appendChild(tr);
      });

    })
    .getUsers(currentUser); // 🔥 여기도!
}

function removeUser(id){

  if(!confirm("정말 삭제할까요?")) return;

  google.script.run.withSuccessHandler(()=>{
    alert("삭제 완료");
    loadUsers();       // 목록 다시 불러오기
    loadRanking(4);    // 랭킹도 갱신
  }).deleteUser(id);
}

// 로그인 + 회원가입
function login(){ 

  google.script.run
    .withSuccessHandler(res=>{
      
      if(res.error){
        alert(res.error);
        return;
      }

currentUser = res.user; // ⭐ 변경
localStorage.setItem("user", JSON.stringify(currentUser)); // ⭐ 변경

      alert("입장 완료");

      setLoginUI(true);

      loadRanking(4);
    })
    .login({
      id: id.value.toLowerCase(), // ⭐ 추가
      password: pw.value
    });
}

function logout(){
  currentUser = null;
  localStorage.removeItem("user");

  alert("로그아웃");

  setLoginUI(false);
}

function setLoginUI(isLogin){

  const loginPage = document.getElementById("loginPage");
  const signupPage = document.getElementById("signupPage");
  const authBtn = document.getElementById("authBtn");
  const mypageBtn = document.getElementById("mypageBtn");
  const userSection = document.getElementById("userSection");

  if(isLogin){
    // 입력창 숨기기
    loginPage.querySelectorAll("input").forEach(el => el.style.display = "none");

    // 회원가입 숨기기
    signupPage.style.display = "none";

    // 마이페이지 버튼 보이기
    mypageBtn.style.display = "inline-block";

    // 🔥 admin만 회원목록 보이기
    if(currentUser && currentUser.role === "admin"){
      userSection.style.display = "block";
        loadUsers(); // 🔥 이거 추가
    }else{
      userSection.style.display = "none";
    }

    // 버튼 변경
    authBtn.innerText = "로그아웃";
    authBtn.onclick = logout;

  }else{
    // 입력창 다시 보이기
    loginPage.querySelectorAll("input").forEach(el => el.style.display = "inline-block");

    // 마이페이지 버튼 숨기기
    mypageBtn.style.display = "none";

    // 🔥 로그아웃 시 회원목록 숨김
    userSection.style.display = "none";

    // 버튼 변경
    authBtn.innerText = "로그인";
    authBtn.onclick = login;
  }
}

function showSignup(){
  document.getElementById("loginPage").style.display = "none";
  document.getElementById("signupPage").style.display = "block";
}

function showLogin(){
  document.getElementById("loginPage").style.display = "block";
  document.getElementById("signupPage").style.display = "none";
}
window.onload = ()=>{

  const savedUser = localStorage.getItem("user");

  if(savedUser){
    currentUser = JSON.parse(savedUser);
    setLoginUI(true);
  }else{
    setLoginUI(false);
  }

  loadRanking(4);
  loadUsers();
};